﻿using AutoIt;
using RGiesecke.DllExport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MT4OrderAutomationLib
{
    public class Class1
    {
        const int AutoITX_True = 1, AutoITX_False = 0;
        static string Market = "Market Execution", Pending = "Pending Order";
        static Dictionary<int, string> OrderTypes = new Dictionary<int, string>() { { 0, "Buy" }, { 1, "Sell" }, { 2, "Buy Limit" }, { 3, "Sell Limit" }, { 4, "Buy Stop" }, { 5, "Sell Stop" } };

        public enum GetAncestorFlags
        {
            GetParent = 1,
            GetRoot = 2,
            GetRootOwner = 3
        }

        static object locker_p = new object();
        [DllExport("PlaceOrder", CallingConvention = CallingConvention.StdCall)]
        public static bool PlaceOrder(int index, long AccountNumber, [MarshalAs(UnmanagedType.LPWStr)] string symbol, int ordertype, [MarshalAs(UnmanagedType.LPWStr)] string lots, [MarshalAs(UnmanagedType.LPWStr)] string price, [MarshalAs(UnmanagedType.LPWStr)] string stoploss, [MarshalAs(UnmanagedType.LPWStr)] string takeprofit, [MarshalAs(UnmanagedType.LPWStr)] string comment)
        {
            lock (locker_p)
            {
                try
                {
                    var MT4_Terminal_Handle = AutoItX.WinGetHandle(AccountNumber.ToString(), "");
                    var MT4_ToolBar_Handle = AutoItX.ControlGetHandle(MT4_Terminal_Handle, "[CLASS:ToolbarWindow32; INSTANCE:4]");

                    AutoItX.ControlSend(MT4_Terminal_Handle, MT4_ToolBar_Handle, "{F9}");
                    AutoItX.WinWait("Order", "Comment", 5);

                    IntPtr MT4_Order_Handle = GetOrderWindowHandle();

                    if (MT4_Order_Handle == IntPtr.Zero)
                    {
                        AutoItX.Sleep(1000);
                        MT4_Order_Handle = GetOrderWindowHandle();
                    }

                    if (MT4_Order_Handle == IntPtr.Zero)
                    {
                        //Log("Cannot get exact order window handle");
                        return false;
                    }

                    IntPtr GetOrderWindowHandle()
                    {
                        var Windows = OpenWindowGetter.GetOpenWindows();
                        var OrderWindows = Windows.Where(a => a.Value.Equals("Order")).ToList();
                        foreach (var window in OrderWindows)
                        {
                            IntPtr rootHandle = OpenWindowGetter.GetAncestor(window.Key, GetAncestorFlags.GetRootOwner);
                            if (rootHandle.Equals(MT4_Terminal_Handle)) return window.Key;
                        }
                        return IntPtr.Zero;
                    }

                    var Symbols_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:ComboBox; INSTANCE:1]");
                    var Lot_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Edit; INSTANCE:1]");
                    var SL_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Edit; INSTANCE:2]");
                    var TP_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Edit; INSTANCE:3]");
                    var Comment_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Edit; INSTANCE:4]");
                    var Sell_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Button; INSTANCE:6]");
                    var Buy_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Button; INSTANCE:7]");
                    var Execution_Type_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:ComboBox; INSTANCE:3]");

                    var Pending_Type_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:ComboBox; INSTANCE:5]");
                    var Pending_Price_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Edit; INSTANCE:6]");
                    var Pending_Place_Handle = AutoItX.ControlGetHandle(MT4_Order_Handle, "[CLASS:Button; INSTANCE:16]");

                    if (!AutoItX.ControlCommand(MT4_Order_Handle, Symbols_Handle, "GetCurrentSelection", "").Contains(symbol))
                        AutoItX.ControlCommand(MT4_Order_Handle, Symbols_Handle, "SetCurrentSelection", index.ToString());
                    ConfirmSymbolIsCorrect(MT4_Order_Handle, Symbols_Handle, symbol);

                    AutoItX.ControlSetText(MT4_Order_Handle, Lot_Handle, lots);

                    if (double.Parse(stoploss) != 0)
                        AutoItX.ControlSend(MT4_Order_Handle, SL_Handle, stoploss);

                    if (double.Parse(takeprofit) != 0)
                        AutoItX.ControlSend(MT4_Order_Handle, TP_Handle, takeprofit);

                    AutoItX.ControlSetText(MT4_Order_Handle, Comment_Handle, comment);

                    if (ordertype < 2)
                    {
                        if (!AutoItX.ControlCommand(MT4_Order_Handle, Execution_Type_Handle, "GetCurrentSelection", "").Contains(Market))
                            AutoItX.ControlCommand(MT4_Order_Handle, Execution_Type_Handle, "SelectString", Market);

                        AutoItX.Sleep(500);
                        AutoItX.ControlClick(MT4_Order_Handle, ordertype == 0 ? Buy_Handle : Sell_Handle);
                    }
                    else
                    {
                        if (!AutoItX.ControlCommand(MT4_Order_Handle, Execution_Type_Handle, "GetCurrentSelection", "").Contains(Pending))
                            AutoItX.ControlCommand(MT4_Order_Handle, Execution_Type_Handle, "SelectString", Pending);
                        AutoItX.ControlCommand(MT4_Order_Handle, Pending_Type_Handle, "SelectString", OrderTypes.Values.ElementAt(ordertype));
                        AutoItX.ControlSend(MT4_Order_Handle, Pending_Price_Handle, price);

                        AutoItX.Sleep(500);
                        AutoItX.ControlClick(MT4_Order_Handle, Pending_Place_Handle);
                    }

                    AutoItX.Sleep(1000);
                    AutoItX.WinClose(MT4_Order_Handle);
                    return true;
                }
                catch (Exception ex)
                {
                    while (ex != null)
                    {
                        //Log(new StackTrace().GetFrame(0).GetMethod().Name + " " + ex.Message); ;
                        ex = ex.InnerException;
                    }
                    return false;
                }
            }
        }

        private static void ConfirmSymbolIsCorrect(IntPtr mT4_Order_Handle, IntPtr symbols_Handle, string symbol)
        {
            //Log("symbols count = " + AutoItX.ControlCommand(mT4_Order_Handle, symbols_Handle, "GetCount", ""));

            if (AutoItX.ControlCommand(mT4_Order_Handle, symbols_Handle, "GetCurrentSelection", "").Contains(symbol)) return;
            int length; int.TryParse(AutoItX.ControlCommand(mT4_Order_Handle, symbols_Handle, "GetCount", ""), out length); //Log( "length " + length);

            for (int i = 0; i < length; i++)
            {
                AutoItX.ControlCommand(mT4_Order_Handle, symbols_Handle, "SetCurrentSelection", i.ToString());
                string sel = AutoItX.ControlCommand(mT4_Order_Handle, symbols_Handle, "GetCurrentSelection", ""); //Log(symbol + " " + sel);
                if (sel.Contains(symbol)) return;
            }
        }

        [DllExport("CloseOrderWindow", CallingConvention = CallingConvention.StdCall)]
        public static void CloseOrderWindow(long AccountNumber)
        {
            var MT4_Terminal_Handle = AutoItX.WinGetHandle(AccountNumber.ToString(), "");
            IntPtr MT4_Order_Handle = GetOrderWindowHandle();

            if (MT4_Order_Handle != IntPtr.Zero)
            {
                AutoItX.WinClose(MT4_Order_Handle);
            }

            IntPtr GetOrderWindowHandle()
            {
                var Windows = OpenWindowGetter.GetOpenWindows();
                var OrderWindows = Windows.Where(a => a.Value.Equals("Order")).ToList();
                foreach (var window in OrderWindows)
                {
                    IntPtr rootHandle = OpenWindowGetter.GetAncestor(window.Key, GetAncestorFlags.GetRootOwner);
                    if (rootHandle.Equals(MT4_Terminal_Handle)) return window.Key;
                }
                return IntPtr.Zero;
            }
        }
    }
}
